# Arabic Bible Android App

App name: Arabic Bible
Home URL: https://tak.la/b

## Build
Open this folder in Android Studio. Let Gradle sync, then choose:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The app requires internet access because it loads the Bible website.
