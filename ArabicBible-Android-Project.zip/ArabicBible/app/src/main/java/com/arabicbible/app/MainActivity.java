package com.arabicbible.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.LinearLayout;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                view.loadUrl(request.getUrl().toString());
                return true;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) showError();
            }
        });

        setContentView(webView);
        webView.loadUrl("https://tak.la/b");
    }

    private void showError() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(17);
        box.setPadding(40,40,40,40);
        TextView title = new TextView(this);
        title.setText("Arabic Bible\n\nUnable to load the Bible.\nPlease check your internet connection.");
        title.setTextSize(20);
        title.setTextColor(Color.DKGRAY);
        title.setGravity(17);
        box.addView(title);
        TextView retry = new TextView(this);
        retry.setText("\nTap here to try again");
        retry.setTextSize(17);
        retry.setTextColor(Color.rgb(109,76,65));
        retry.setGravity(17);
        retry.setOnClickListener(v -> webView.loadUrl("https://tak.la/b"));
        box.addView(retry);
        setContentView(box);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
